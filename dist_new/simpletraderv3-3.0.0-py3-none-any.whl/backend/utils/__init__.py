"""Backend utilities."""
